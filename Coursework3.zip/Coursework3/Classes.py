###################################################################################################
###################################################################################################
###################################################################################################
################################           Coursework 3             ###############################
################################      Candidate Number: SKGR8       ###############################
###################################################################################################
###################################################################################################
###################################################################################################

#### This file defines classes used in the experiment ####


import sys

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from enum import IntEnum


# Create a class for a widget responsive to keyboard keys
class QKeyboardWidget(QWidget):

    keyPressed = pyqtSignal(str)  # create a custom signal

    # Override the keyPressEvent function to emit a signal containing the pressed key
    def keyPressEvent(self, keyEvent):
        self.keyPressed.emit(keyEvent.text())


# Create a class for labels that can easily change the colour of the text
# For example, .setColour('red') will change the colour of the text to red
class QColouredLabel(QLabel):

    def setColour(self, colourString):
        labelPalette = self.palette()
        labelPalette.setColor(QPalette.WindowText, QColor(colourString))
        self.setPalette(labelPalette)


# Create a class for enumerated constants to improve code readability
# These are used to replace the index of each page in the experiment with what they represent
# Integer enums are used, as enumerations are used for the indices (which are integers)
# All pages are listed for clarity, although not all of the enums are used
class Pages(IntEnum):
    INFORMATION_SHEET = 0
    CONSENT_FORM = 1
    DEMOGRAPHICS_QUESTIONNAIRE = 2
    GENERAL_INSTRUCTIONS = 3
    COMPARATIVE_QUESTION_INSTRUCTIONS = 4
    COMPARATIVE_QUESTION = 5
    COMPARATIVE_IMAGE_INSTRUCTIONS = 6
    COMPARATIVE_IMAGE = 7
    LDT_INSTRUCTIONS = 8
    FIXATION_CROSS = 9
    BLANK_PAGE = 10
    LDT_WORD = 11
    ABSOLUTE_QUESTION = 12
    BREAK_BETWEEN_BLOCKS = 13
    DEBRIEF = 14
