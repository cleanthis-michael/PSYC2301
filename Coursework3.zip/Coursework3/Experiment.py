###################################################################################################
###################################################################################################
###################################################################################################
################################           Coursework 3             ###############################
################################      Candidate Number: SKGR8       ###############################
###################################################################################################
###################################################################################################
###################################################################################################

#### This file contains the code regarding the user interface (the experiment) ####


import sys

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from Experiment_Interface import *

from random import randint, shuffle
from Classes import *
from Functions import *

# Set up the windowed application
app = QApplication(sys.argv)
window = QMainWindow()
ui = Ui_AnchoringWindow()
ui.setupUi(window)


######## The experiment is written in a stacked widget ########
# Every page of the stacked widget contains one aspect of the experiment:
##    Index 0: Information Sheet
##    Index 1: Consent Form
##    Index 2: Demographics Questionnaire
##    Index 3: Instructions about the General Task
##    Index 4: Instructions about the Comparative Question
##    Index 5: Comparative Question ('Does a car/dog cost/weigh on average higher or lower than X?'; where X is the anchor)
##    Index 6: Instructions about the Comparative Image (image with high/low salary/temperature)
##    Index 7: Comparative Image
##    Index 8: Instructions about the Lexical-Decision Task (shown letter strings to determine whether they constitute meaningful English words or not)
##    Index 9: Fixation Cross
##    Index 10: Blank Page (in-between fixation cross and LDT word)
##    Index 11: LDT word
##    Index 12: Absolute Question Page (estimate an exact value regarding the topic asked or inspected before)
##    Index 13: Break between Blocks
##    Index 14: Debrief


### Experimental Task ###
# Participants will answer a comparative question or inspect a comparative image, which will anchor them
# They will complete a LDT with control, anchor-congruent, anchor-incongruent, anchor-irrelevant and non-words
# They will lastly estimate the exact value regarding the topic asked or inspected before
# They will then complete 3 more blocks
# There are 2 blocks with a comparative question and 2 blocks with a comparative image


### Defining Functions ###

# Define a function for when the 'next' button (btnNext) is clicked
# The button will check for errors based on the current index of the stacked widget
# If there are no errors, it will take participants to the appropriate page
def NextPage():

    currentIndex = ui.stackedWidget.currentIndex()
    nextPageIndex = currentIndex + 1
    noErrors = True  # a boolean indicating whether there are any errors in the current page

    if currentIndex == Pages.CONSENT_FORM: noErrors = checkConsentError()  # using enumerations for clearer readability
    elif currentIndex == Pages.DEMOGRAPHICS_QUESTIONNAIRE: noErrors = checkDemographicsErrors()
    elif currentIndex == Pages.ABSOLUTE_QUESTION: noErrors = checkAbsoluteQuestionError()

    # If noErrors is false, the function will not enter the conditional
    # Therefore, the experiment will not change page when the 'next' button is clicked
    if noErrors:

        ## Demographics Questionnaire ##
        # The focus in the demographics questionnaire is set on the last information provided e.g. lineEditLanguage
        # Therefore, upon changing page, the focus will be set on the widget responding to specific keyboard keys, based on the current index
        if currentIndex == Pages.DEMOGRAPHICS_QUESTIONNAIRE:

            ui.stackedWidget.setCurrentIndex(Pages.GENERAL_INSTRUCTIONS)
            responseKeyWidget.setFocus()
            resultsCSV.write('\n{0},{1},{2},{3},{4}'.format(window.participantAge, window.participantGender,
                                                            window.participantLanguage, window.participantEducation,
                                                            anchorCondition))


        ## General Instructions Page ##
        elif currentIndex == Pages.GENERAL_INSTRUCTIONS:

            # If firstCondition is 'car' or 'dog' (comparative question conditions),
            # participants will go to the comparative question instructions
            # If firstCondition is not 'car' or 'dog', they will go to the comparative image instructions
            if (firstCondition == 'car') or (firstCondition == 'dog'): ui.stackedWidget.setCurrentIndex(Pages.COMPARATIVE_QUESTION_INSTRUCTIONS)
            else: ui.stackedWidget.setCurrentIndex(Pages.COMPARATIVE_IMAGE_INSTRUCTIONS)
            ui.btnNext.hide()  # from here onwards, participants will respond using the keyboard


        ## Absolute Question Page ##
        elif currentIndex == Pages.ABSOLUTE_QUESTION:

            absoluteAnswer = ui.lineEditAbsoluteAnswer.text()
            resultsCSV.write(',{0}'.format(absoluteAnswer))

            # window.numberOfConditions indicates how many (out of 4) conditions are left
            if window.numberOfConditions != 0:  # if there are more conditions left,
                ui.stackedWidget.setCurrentIndex(Pages.BREAK_BETWEEN_BLOCKS)  # participants will go to the break between blocks page
                ui.lineEditAbsoluteAnswer.setText('')  # reset the text to be empty in the next block
                responseKeyWidget.setFocus()  # reset the focus from the lineEdit to the keyboard widget

            else:  # if no conditions are left,
                ui.stackedWidget.setCurrentIndex(Pages.DEBRIEF)  # participants will go to the debrief page
                ui.btnNext.setText('Finish')  # the button will be labelled 'Finish' rather than 'Next' at the last page


        ## Break between Blocks Page ##
        # Participants enter this page only if more conditions are left
        # Pressing 'Next' will take participants to the page containing the instructions
        # for either the comparative question or comparative image conditions
        elif currentIndex == Pages.BREAK_BETWEEN_BLOCKS:
            if (window.nextCondition == 'car') or (window.nextCondition == 'dog'): ui.stackedWidget.setCurrentIndex(Pages.COMPARATIVE_QUESTION_INSTRUCTIONS)
            else: ui.stackedWidget.setCurrentIndex(Pages.COMPARATIVE_IMAGE_INSTRUCTIONS)
            ui.btnNext.hide()  # participants will start another block, hence will respond using the keyboard


        ## Debrief Page ##
        elif currentIndex == Pages.DEBRIEF:
            resultsCSV.close()
            sys.exit()


        ## Every Other Page where the 'Next' button is not hidden (information sheet, general instructions) ##
        else: ui.stackedWidget.setCurrentIndex(nextPageIndex)


# Define a function that checks whether participants checked the consent box in the consent form
# If not, a red arrow will nudge next to the consent box to indicate what they must do before continuing
def checkConsentError():

    if ui.checkBoxConsent.isChecked(): return True  # such that noErrors = True
    else:
        ui.lblConsentError.show()  # will indicate that participants must consent before continuing
        ui.consentArrow.show()  # a red arrow will appear next to the check box to clarify what is required

        window.nudgeItems.append(ui.consentArrow)  # every item in the 'nudgeItems' list will nudge (see functions 'ResetNudgeTimer()' and 'Nudge()' below)
        window.nudgeTimer.start(50)  # the red arrow will nudge to indicate what is required before continuing
        return False  # such that noErrors = False


# Define a function that checks whether participants provided all the information in the demographics form
# If not, an error message will indicate what information participants have not provided, and
# a red arrow will nudge next to the missing fields
def checkDemographicsErrors():

    errors = []  # will contain error messages for each field that was not answered
    ageError = 'Please indicate your age.'
    youngAgeError = 'You must be over 18 to participate.'
    genderError = 'Please indicate your gender.'
    languageError = 'Please indicate your native language.'
    educationError = 'Please indicate your highest level of education.'

    ### Age ###
    # Participants indicate their age from a spin box
    if ui.spBoxAge.value() == 0: errors.append(ageError)
    elif ui.spBoxAge.value() < 18: errors.append(youngAgeError)

    ### Gender ###
    # The radio buttons for participants to indicate their gender are contained in a widget (widgetGender)
    # If one of the three buttons in the widget is checked, the 'noGender' boolean will become False
    noGender = True  # a boolean indicating whether participants reported their gender

    for gender in ui.widgetGender.children():
        if gender.isChecked(): noGender = False

    if noGender: errors.append(genderError)  # if 'noGender' remains True, participants did not indicate their gender

    ### Language ###
    # If participants write nothing, or write numbers, or both letters and numbers, an error message will appear
    if not ui.lineEditNativeLanguage.text().isalpha(): errors.append(languageError)

    ### Education ###
    # Index 0 of the education combo box reads 'Please indicate your highest level of education'
    # Therefore, if the current index is 0, this will mark that participants did not answer the field
    if ui.cmbBoxEducation.currentIndex() == 0: errors.append(educationError)

    ### Error Message ###
    errorMessage = '\n'.join(errors)  # every error message will appear in a new line

    # If there are no errors, the participant's demographics will be saved in variables
    # These will be written in the csv file registering the results (resultsCSV)
    if errorMessage == '':

        window.participantAge = ui.spBoxAge.value()
        for gender in ui.widgetGender.children():
            if gender.isChecked(): window.participantGender = gender.objectName()
        window.participantLanguage = ui.lineEditNativeLanguage.text()
        window.participantEducation = ui.cmbBoxEducation.currentText()

        return True  # such that noErrors = True

    else:  # if the error message is not empty

        ui.lblDemogError.setText(errorMessage)

        # For every error, a red arrow will nudge next to the field with the missing information
        # When participants then provide the missing information but there is other information still missing,
        # the red arrow from the corrected field will be hidden when they click 'next'
        if (ageError in errorMessage) or (youngAgeError in errorMessage):
            ui.ageArrow.show()
            window.nudgeItems.append(ui.ageArrow)
        else: ui.ageArrow.hide()

        if genderError in errorMessage:
            ui.genderArrow.show()
            window.nudgeItems.append(ui.genderArrow)
        else: ui.genderArrow.hide()

        if languageError in errorMessage:
            ui.languageArrow.show()
            window.nudgeItems.append(ui.languageArrow)
        else: ui.languageArrow.hide()

        if educationError in errorMessage:
            ui.educationArrow.show()
            window.nudgeItems.append(ui.educationArrow)
        else: ui.educationArrow.hide()

        window.nudgeTimer.start(50)  # this will nudge the red arrows next to the missing information
        return False  # such that noErrors = False


# Define a function that checks whether participants answered the absolute question
# If not, a red arrow will nudge next to the field to indicate that they must answer before continuing
def checkAbsoluteQuestionError():

    if ui.lineEditAbsoluteAnswer.text().isdigit():
        if ui.lblAbsoluteQuestionError.isVisible():  # if an error was made, the error message will be visible
            ui.absoluteAnswerArrow.hide()  # the arrow will be hidden for the next block to be ready
            ui.lblAbsoluteQuestionError.hide()  # the error message will be hidden for the next block to be ready
        return True  # such that noErrors = True

    else:
        ui.lblAbsoluteQuestionError.show()
        ui.absoluteAnswerArrow.show()

        if ui.lineEditAbsoluteAnswer.text() == '': ui.lblAbsoluteQuestionError.setText('You must answer the question before continuing.')
        else: ui.lblAbsoluteQuestionError.setText('Please provide your answer only with integer numbers.')

        window.nudgeItems.append(ui.absoluteAnswerArrow)
        window.nudgeTimer.start(50)  # the red arrow next to the lineEdit will nudge
        return False  # such that noErrors = False


# Define a function that sets up the variables to nudge the red arrows next to the missing information
# The first time it is called, it will initialize the nudge variables
# Every other time the function is called, the variables will be reset
def ResetNudgeTimer():

    window.nudgeTimer = QTimer()  # set up a timer to animate the red arrows next to the missing information
    window.nudgeLeft = True  # set up a boolean to indicate whether the arrows will move to the left or right
    window.nudgeCounter = 0  # every time the arrow moves, the counter will increase by 1. When it reaches 4, the timer will stop and the arrows will stop nudging
    window.nudgeItems = []  # the list will contain every item that will animate
    window.nudgeTimer.timeout.connect(Nudge)


# Define a function to nudge the red arrows contained in the 'nudgeItems' list
def Nudge():

    nudgeRange = 10

    # After an arrow nudged to the left/right, the nudgeLeft boolean will become false/true,
    # such that the arrow will next nudge to the right/left
    if window.nudgeLeft: window.nudgeLeft = False
    else: window.nudgeLeft = True

    for nudgeItem in window.nudgeItems:
        if window.nudgeLeft == False: nudgeItem.setGeometry(nudgeItem.x() + nudgeRange, nudgeItem.y(), nudgeItem.width(), nudgeItem.height())
        else: nudgeItem.setGeometry(nudgeItem.x() - nudgeRange, nudgeItem.y(), nudgeItem.width(), nudgeItem.height())

    window.nudgeCounter += 1
    if window.nudgeCounter == 4:  # when the arrows nudge 4 times,
        window.nudgeTimer.stop()  # the timer will stop to stop nudging the arrows
        ResetNudgeTimer()  # reset the nudge variables


# Define a function that sets up the variables and instructions for the current experimental condition (car/dog/salary/temperature)
def SetUpExperiment():

    # The experiment has 4 conditions ('car', 'dog', 'salary' and 'temperature')
    # These are saved in the variables firstCondition, secondCondition, thirdCondition and lastCondition
    if window.numberOfConditions == 4:  # window.numberOfConditions indicates how many (out of the 4) conditions are left
        window.currentCondition = firstCondition
        window.nextCondition = secondCondition
        ui.lblBlocksLeft.setText(blocksLeft.format('are', '3', 's'))  # in the break between blocks page: 'There are 3 blocks left.'

    elif window.numberOfConditions == 3:
        window.currentCondition = secondCondition
        window.nextCondition = thirdCondition
        ui.lblBlocksLeft.setText(blocksLeft.format('are', '2', 's'))  # 'There are 2 blocks left.'

    elif window.numberOfConditions == 2:
        window.currentCondition = thirdCondition
        window.nextCondition = lastCondition
        ui.lblBlocksLeft.setText(blocksLeft.format('is', '1', ''))  # 'There is 1 block left.'

    else: window.currentCondition = lastCondition

    resultsCSV.write(',{0}'.format(window.currentCondition))

    # Derive the comparative question, LDT and absolute question for the current condition
    # These are all saved in a rich dictionary (conditionData)
    # with condition as a key (car, dog, salary, temperature)
    # with a value of 3 keys for the corresponding comparative question, LDT and absolute question
    # For example, conditionData['dog']['LDT'] accesses the LDT for the dog condition
    if (window.currentCondition == 'car') or (window.currentCondition == 'dog'): ui.lblComparativeQuestion.setText(conditionData[window.currentCondition]['ComparativeQuestion'])
    else: ui.ComparativeImage.setPixmap(conditionData[window.currentCondition]['ComparativeImage'])
    window.currentLDT = conditionData[window.currentCondition]['LDT']
    window.currentAbsoluteQuestion = conditionData[window.currentCondition]['AbsoluteQuestion']


# Define a function for the widget responding to keyboard keys
# This will execute different functions based on the current index of the stacked widget
def OnKeyPress(pressedKey):

    pressedKey = pressedKey.lower()  # to work for both higher and lower case ('E' or 'e') e.g. if caps lock is on
    currentIndex = ui.stackedWidget.currentIndex()

    ## Question or Image Instructions Page ##
    if (currentIndex == Pages.COMPARATIVE_QUESTION_INSTRUCTIONS) or (currentIndex == Pages.COMPARATIVE_IMAGE_INSTRUCTIONS):
        if pressedKey == ' ':  # spacebar
            SetUpExperiment()  # set up the variables and instructions for the current condition

            # If participants are at the comparative image instructions page, pressing spacebar will
            # take them to the comparative image, which they must inspect for at least 5 seconds
            # ensuring sufficient inspection to be theoretically anchored by the image
            # Therefore, a timer will start, timing out after 5 seconds and stopping (see function 'OnLDTtimerTimeout()' below)
            if currentIndex == Pages.COMPARATIVE_IMAGE_INSTRUCTIONS: window.LDTtimer.start(5000)

            ui.stackedWidget.setCurrentIndex(currentIndex + 1)  # comparative question or comparative image


    ## Comparative Question Page ##
    # The participant's response to the comparative question (higher or lower) will be written in the csv file
    elif currentIndex == Pages.COMPARATIVE_QUESTION:
        if (pressedKey == 'e') or (pressedKey == 'i'):
            ui.stackedWidget.setCurrentIndex(Pages.LDT_INSTRUCTIONS)

            # 'e' or 'i' are counterbalanced to represent 'higher' or 'lower'
            # This is represented by the variables ePressComparativeQuestion and iPressComparativeQuestion
            if pressedKey == 'e': resultsCSV.write(',{0}'.format(ePressComparativeQuestion))
            else: resultsCSV.write(',{0}'.format(iPressComparativeQuestion))


    ## Comparative Image Page ##
    # Participants must inspect the comparative image for at least 5 seconds, to ensure that they look at the image
    # The timer starts when they press spacebar from the previous page (i.e. as soon as they enter this page)
    elif currentIndex == Pages.COMPARATIVE_IMAGE:
        if pressedKey == ' ':
            # If participants press the spacebar while the timer is still running, an error message will appear
            if window.LDTtimer.isActive(): ui.lblComparativeImageError.show()
            else:  # the timer times out and stops running after 5 seconds
                ui.stackedWidget.setCurrentIndex(Pages.LDT_INSTRUCTIONS)
                ui.lblComparativeImageError.hide()  # to be ready for the next image block
                resultsCSV.write(',none')  # participants inspect the image, so there is no 'higher'/'lower' response


    ## LDT Instructions Page
    elif currentIndex == Pages.LDT_INSTRUCTIONS:
        if pressedKey == ' ': StartLDT()


    ## LDT Word Page ##
    elif currentIndex == Pages.LDT_WORD:
        if (pressedKey == 'e') or (pressedKey == 'i'):

            # 'e' and 'i' are counterbalanced to represent 'word' or 'non-word'
            # This is represented by the variables ePressLDT and iPressLDT
            if pressedKey == 'e': LDTresponse = ePressLDT
            else: LDTresponse = iPressLDT

            responseTime = window.LDTResponseTimer.elapsed()  # .elapsed() saves the time the response key was pressed
                                                              # and automatically calculates the difference between
                                                              # the time it started and this time (= response time)

            resultsCSV.write(',{0},{1}'.format(LDTresponse, responseTime))

            window.LDTtimer.stop()  # stop the timer measuring how much time participants have left to respond
            StartLDT()  # start a new trial


# Define a function that derives the LDT word for each trial
# The function is called every time participants respond to an LDT word, or they run out of time to respond
# Based on whether the block has more trials left, this will take them either to the fixation cross or the absolute question
def StartLDT():

    if len(window.currentLDT) != 0:  # if there are more trials left,
        ui.stackedWidget.setCurrentIndex(Pages.FIXATION_CROSS)  # take participants to the fixation cross page,
        window.preLDTwordTimer.start(300)  # which will be presented for 300ms
        
        # Every time a word is presented, that word will be removed from the currentLDT list
        # In each LDT, the control words (originally set at 2) will be presented first in a randomized order
        # Then, the non-control words (originally set at 8) will be presented in an independently randomized order
        # window.criticalWordNumber contains the number of non-control words used in each LDT
        # If the length of currentLDT is higher than that, then the control words have not yet been presented
        if len(window.currentLDT) > window.criticalWordNumber:
            randomWord = randint(0, (window.controlWordNumber - 1))  # random number to access a random control word
            window.controlWordNumber -= 1  # the number of control words left is 1 less
        else: randomWord = randint(0, len(window.currentLDT) - 1)  # random number to access a random non-control word

        LDTword = window.currentLDT[randomWord]  # access the word from the list containing the LDT's words
        resultsCSV.write(',{0}'.format(LDTword))
        ui.lblLexicalDecisionWord.setText(LDTword)
        window.currentLDT.remove(LDTword)  # each word tested is removed from the list
                                           # when no words are left in the list,
                                           # the function will enter the 'else' statement

    else:  # if no trials are left,
        window.numberOfConditions -= 1  # the number of conditions left decreases by 1
        window.controlWordNumber = 2  # reset the number of control words to be ready for the next block
        ui.lblAbsoluteQuestion.setText(window.currentAbsoluteQuestion)
        ui.stackedWidget.setCurrentIndex(Pages.ABSOLUTE_QUESTION)
        ui.btnNext.show()


# Define a function for when the timer used in the fixation cross and blank pages times out
def OnPreLDTwordTimerTimeout():

    currentIndex = ui.stackedWidget.currentIndex()

    if currentIndex == Pages.FIXATION_CROSS: ui.stackedWidget.setCurrentIndex(Pages.BLANK_PAGE)
    else:  # from blank page to LDT word page
        ui.stackedWidget.setCurrentIndex(Pages.LDT_WORD)
        resetTimeLeftLabel()  # reset the label indicating how much time participants have left
        window.preLDTwordTimer.stop()
        window.LDTtimer.start(1000)  # participants have 10 seconds to respond to the LDT word
                                     # the label indicating how much time is left will be updated every second
                                     # when it reaches 0, it will start the next trial (see function 'OnLDTtimerTimeout()' below)
        window.LDTResponseTimer.start()  # .start() does not start a timer, but instead saves automatically the current
                                         # time, which will later be used to calculate the participant's response time
                                         # by calculating how much time passed when .elapsed() is called


# Define a function for when the timer used in the LDT word page times out
# The same timer is also used in the comparative image page (rather than setting up more timers), where participants
# must inspect the image for at least 5 seconds, ensuring that they attend to the 'anchor' image
# In the LDT, it will update the label indicating how much time is left for participants to respond
# The label will not appear until 3 seconds are left. When 10 seconds pass, the next LDT trial will begin
def OnLDTtimerTimeout():

    # At the comparative image page, participants must inspect the image for at least 5 seconds
    # Once the timer times out (after 5 seconds), it will stop running
    # Therefore, participants can move on to the next page by pressing the spacebar
    if ui.stackedWidget.currentIndex() == Pages.COMPARATIVE_IMAGE: window.LDTtimer.stop()

    # The timer is used again at the LDT word page
    # It times out every second, and writes the time participants have left to respond to the LDT word
    else:
        currentTimeLeft = lblTimeLeft.text()
        timeLeft = int(currentTimeLeft) - 1
        lblTimeLeft.setText(str(timeLeft))

        if timeLeft == 3: lblTimeLeft.show()  # participants will be informed when they have 3 seconds left
        elif timeLeft == 2: lblTimeLeft.setColour('orange')
        elif timeLeft == 1: lblTimeLeft.setColour('red')
        elif timeLeft == 0:  # if 10 seconds pass without participants responding to the LDT word:
            window.LDTtimer.stop()
            resetTimeLeftLabel()  # the label indicating how much time participants have left will reset
            resultsCSV.write(',none,none')  # no response and no response time for that LDT word
            StartLDT()  # the next LDT trial will begin


# Define a function that resets the label indicating how much time participants have left to respond to the LDT word
def resetTimeLeftLabel():

    lblTimeLeft.setColour('black')
    lblTimeLeft.hide()  # as it will only appear in the last 3 seconds
    lblTimeLeft.setText('10')



#### Experiment ####


# Create a csv file at the location where the python file is saved, which will register the participants' data (one participant per row)
resultsCSV = open('Experiment Results.csv', 'a')

# The contents of the csv file will also be read to determine each participant's condition
csvContent = open('Experiment Results.csv', 'r')
results = csvContent.readlines()
resultsLength = len(results)
csvContent.close()

# If nothing is written in the csv file, the length of the 'results' list will be 0
# Therefore, labels for what each column will represent will be written in the first row of the csv file
# The first participant will be randomly assigned to either the low or high anchor condition
if resultsLength == 0:

    resultsCSV.write('Age,Gender,Native Language,Education,Anchor Condition (0 = low/1 = high),'
                     'First Condition,Answer to Comparative Question,Control Word 1,Response,'
                     'Response Time,Control Word 2,Response,Response Time,Word 1,Response,'
                     'Response Time,Word 2,Response,Response Time,Word 3,Response,Response Time,'
                     'Word 4,Response,Response Time,Word 5,Response,Response Time,Word 6,Response,'
                     'Response Time,Word 7,Response,Response Time,Word 8,Response,Response Time,'
                     'Absolute Estimate,Second Condition,Answer to Comparative Question,Control Word 1,'
                     'Response,Response Time,Control Word 2,Response,Response Time,Word 1,Response,'
                     'Response Time,Word 2,Response,Response Time,Word 3,Response,Response Time,'
                     'Word 4,Response,Response Time,Word 5,Response,Response Time,Word 6,Response,Response Time,'
                     'Word 7,Response,Response Time,Word 8,Response,Response Time,Absolute Estimate,'
                     'Third Condition,Answer to Comparative Question,Control Word 1,Response,'
                     'Response Time,Control Word 2,Response,Response Time,Word 1,Response,'
                     'Response Time,Word 2,Response,Response Time,Word 3,Response,Response Time,'
                     'Word 4,Response,Response Time,Word 5,Response,Response Time,Word 6,Response,'
                     'Response Time,Word 7,Response,Response Time,Word 8,Response,Response Time,'
                     'Absolute Estimate,Last Condition,Answer to Comparative Question,Control Word 1,'
                     'Response,Response Time,Control Word 2,Response,Response Time,Word 1,Response,'
                     'Response Time,Word 2,Response,Response Time,Word 3,Response,Response Time,'
                     'Word 4,Response,Response Time,Word 5,Response,Response Time,Word 6,Response,Response Time,'
                     'Word 7,Response,Response Time,Word 8,Response,Response Time,Absolute Estimate')

    anchorCondition = randint(0, 1)  # 0 = low anchor, 1 = high anchor

# Instead, if the csv file contains data, the 'results' list format will be converted to contain sublists,
# each sublist containing one participant's data
# In order to ensure that each condition has the same number of participants,
# the number of participants in the low and high anchor condition who completed the experiment will be counted
# If one condition has more participants, the next participant will complete the other condition
# If the 2 conditions have the same number of participants, the next participant will be randomly assigned
else:

    results = convertListFormat(results)
    anchorCondition = deriveAnchorCondition(results)


#### Consent Form ####
ui.lblConsentError.hide()  # the error message will only appear if 'next' is clicked without consenting
ui.consentArrow.hide()  # will only appear if 'next' is clicked without consenting
ResetNudgeTimer()  # call once to initialize the nudge variables


#### Demographics Form ####
ui.ageArrow.hide()  # will only appear if the participant clicks 'next' without indicating their age
ui.genderArrow.hide()  # will only appear if the participant clicks 'next' without indicating their gender
ui.languageArrow.hide()  # will only appear if the participant clicks 'next' without indicating their native language
ui.educationArrow.hide()  # will only appear if the participant clicks 'next' without indicating their education level


#### Comparative Image ####
ui.lblComparativeImageError.hide()  # will only appear if participants press spacebar without inspecting the image for at least 5 seconds


#### Absolute Question ####
ui.lblAbsoluteQuestionError.hide()  # will only appear if the participant clicks 'next' without answering the question
ui.absoluteAnswerArrow.hide()  # will only appear if the participant clicks 'next' without answering the question


#### Experimental Task ####
# Participants will be presented with a comparative question or a comparative image
# In the comparative question condition, participants must answer whether something is higher or lower than the anchor
# They will respond using 'E' or 'I' on the keyboard, with key assignment counterbalanced across participants
comparativeQuestionInstructions = "Press 'E' for {0} or 'I' for {1}."

EorIforComparativeQuestion = randint(0, 1)
if EorIforComparativeQuestion == 0:  # 'E' = higher, 'I' = lower
    ePressComparativeQuestion = 'higher'
    iPressComparativeQuestion = 'lower'

else:  # 'E' = lower, 'I' = higher
    ePressComparativeQuestion = 'lower'
    iPressComparativeQuestion = 'higher'

ui.lblComparativeQuestionInstructions.setText(comparativeQuestionInstructions.format(ePressComparativeQuestion, iPressComparativeQuestion))

# Participants will then complete a lexical-decision task by indicating whether letter strings
# constitute meaningful English words or not by pressing 'E' or 'I' on the keyboard
# Again, key assignment will be counterbalanced across participants
EorItext = "Press 'E' to indicate that the string is {0}a word and 'I' to indicate that the string is {1}a word."

EorIforLDT = randint(0, 1)
if EorIforLDT == 0:  # 'E' = word, 'I' = non-word
    ePressLDT = 'word'
    iPressLDT = 'non-word'
    ui.lblAssignmentOfEorI.setText(EorItext.format('', 'not '))  # will appear in the LDT instructions
    ui.lblReminderOfEorI.setText(EorItext.format('', 'not '))  # will appear in the LDT

else:  # 'E' = non-word, 'I' = word
    ePressLDT = 'non-word'
    iPressLDT = 'word'
    ui.lblAssignmentOfEorI.setText(EorItext.format('not ', ''))
    ui.lblReminderOfEorI.setText(EorItext.format('not ', ''))

# Set up a label in the LDT word page, which will indicate how much time participants have left to respond
# The number in the label will become orange when 2 seconds are left, and red when 1 second is left
lblTimeLeft = QColouredLabel(ui.LexicalDecisionPage)
lblTimeLeft.setGeometry(620, 580, 51, 51)
lblTimeLeft.setAlignment(Qt.AlignCenter)
font = QtGui.QFont()
font.setPointSize(24)
lblTimeLeft.setFont(font)


### Setting up the comparative questions/images, LDTs and absolute questions ###

# Creating a list containing the absolute questions for all 4 conditions
# Index 0 = car; Index 1 = dog; Index 2 = salary; Index 3 = temperature
absoluteQuestionsFile = open('AbsoluteQuestions/AbsoluteQuestions.txt', 'r')
absoluteQuestions = absoluteQuestionsFile.readlines()
absoluteQuestionsFile.close()

### Comparative Question Conditions ###
# Setting up the variables containing each condition's comparative question, LDT and absolute question
# The two comparative questions for each condition are saved in the folder 'ComparativeQuestions'
# Index 0 is the low-anchor version and Index 1 is the high-anchor version of the question
carFile = open('ComparativeQuestions/CarComparativeQuestions.txt', 'r')
carComparativeQuestions = carFile.readlines()
carLDTfile = open('LexicalDecisionTasks/CarLDT.txt', 'r')
carLDT = carLDTfile.readlines()
carAbsoluteQuestion = absoluteQuestions[0]
carFile.close()
carLDTfile.close()

dogFile = open('ComparativeQuestions/DogComparativeQuestions.txt', 'r')
dogComparativeQuestions = dogFile.readlines()
dogLDTfile = open('LexicalDecisionTasks/DogLDT.txt', 'r')
dogLDT = dogLDTfile.readlines()
dogAbsoluteQuestion = absoluteQuestions[1]
dogFile.close()
dogLDTfile.close()

### Comparative Image Conditions ###
# The high and low anchor images for each condition are saved in the folder 'ComparativeImages'
highSalary = QPixmap('ComparativeImages/Salary/HighSalary.jpg')
lowSalary = QPixmap('ComparativeImages/Salary/LowSalary.jpg')
salaryLDTfile = open('LexicalDecisionTasks/SalaryLDT.txt', 'r')
salaryLDT = salaryLDTfile.readlines()
salaryAbsoluteQuestion = absoluteQuestions[2]
salaryLDTfile.close()

highTemperature = QPixmap('ComparativeImages/Temperature/HighTemperature.jpg')
lowTemperature = QPixmap('ComparativeImages/Temperature/LowTemperature.jpg')
temperatureLDTfile = open('LexicalDecisionTasks/TemperatureLDT.txt', 'r')
temperatureLDT = temperatureLDTfile.readlines()
temperatureAbsoluteQuestion = absoluteQuestions[3]
temperatureLDTfile.close()

# Set up the comparative images, based on the participant's anchor condition
if anchorCondition == 0:
    salaryComparativeImage = lowSalary
    temperatureComparativeImage = lowTemperature
else:
    salaryComparativeImage = highSalary
    temperatureComparativeImage = highTemperature

# Set up the final LDTs (remove '\n' from each letter string)
# Therefore, when the words are subsequently written in the csv file,
# they will all be written in the same line, rather than each word appearing in a new line
for LDTword in range(0, (len(carLDT) - 1)):  # each LDT has equal number of trials (10)
    carLDT[LDTword] = carLDT[LDTword].strip('\n')
    dogLDT[LDTword] = dogLDT[LDTword].strip('\n')
    salaryLDT[LDTword] = salaryLDT[LDTword].strip('\n')
    temperatureLDT[LDTword] = temperatureLDT[LDTword].strip('\n')


# Set up the order in which participants will complete each condition
conditions = ['car', 'dog', 'salary', 'temperature']
shuffle(conditions)  # randomly shuffle the order in the list

# The new list order will represent the order in which participants will complete the conditions
firstCondition = conditions[0]
secondCondition = conditions[1]
thirdCondition = conditions[2]
lastCondition = conditions[3]


# Set up a rich dictionary
# The key represents each condition (car, dog, salary and temperature)
# The value of each key contains 3 more keys = ComparativeQuestion, LDT and AbsoluteQuestion for each condition
# For example, conditionData['salary']['LDT'] will access the LDT for the salary condition
conditionData = {'car': {'ComparativeQuestion': carComparativeQuestions[anchorCondition], 'LDT': carLDT, 'AbsoluteQuestion': carAbsoluteQuestion},
                 'dog': {'ComparativeQuestion': dogComparativeQuestions[anchorCondition], 'LDT': dogLDT, 'AbsoluteQuestion': dogAbsoluteQuestion},
                 'salary': {'ComparativeImage': salaryComparativeImage, 'LDT': salaryLDT, 'AbsoluteQuestion': salaryAbsoluteQuestion},
                 'temperature': {'ComparativeImage': temperatureComparativeImage, 'LDT': temperatureLDT, 'AbsoluteQuestion': temperatureAbsoluteQuestion}}

# Set up the total number of conditions each participant will complete
# Set up a variable which will indicate how many blocks are left in the 'BreakBetweenBlocks' page
window.numberOfConditions = 4
blocksLeft = 'There {0} {1} block{2} left.'  # There is/are 1/2/3 block/s left'

# Set up variables to determine the number of control and non-control words in each LDT
window.controlWordNumber = 2  # the number of control words in each LDT
window.criticalWordNumber = len(carLDT) - window.controlWordNumber  # the number of non-control words in each LDT

# Create a widget that responds to keyboard keys and connect it to its function
responseKeyWidget = QKeyboardWidget(window)
responseKeyWidget.keyPressed.connect(OnKeyPress)

# Set up the timers used in the experiment and connect them to their functions
window.preLDTwordTimer = QTimer()  # used in the fixation cross and blank pages (each presented for 300ms)
window.LDTtimer = QTimer()  # used in the LDT word page (10 seconds to respond) and comparative image page (inspect image for at least 5 seconds)
window.LDTResponseTimer = QElapsedTimer()  # used in the LDT word page to measure the participant's response time
                                           # .start() does not start a timer, but saves the time when .start() was called
                                           # .elapsed() saves the time when .elapsed() was called to calculate
                                           # how much time passed since .start() was called (= response time)

window.preLDTwordTimer.timeout.connect(OnPreLDTwordTimerTimeout)
window.LDTtimer.timeout.connect(OnLDTtimerTimeout)
ui.btnNext.clicked.connect(NextPage)

window.show()
sys.exit(app.exec_())
