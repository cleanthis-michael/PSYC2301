###################################################################################################
###################################################################################################
###################################################################################################
################################           Coursework 3             ###############################
################################      Candidate Number: SKGR8       ###############################
###################################################################################################
###################################################################################################
###################################################################################################

#### This file defines utility functions used in the experiment ####


from random import randint


# Define a function which, when given a list of all the participants' data so far,
# will convert the list of strings into a list of sublists,
# each sublist containing one participant's data
def convertListFormat(listOfData):

    for i in range(len(listOfData)):
        newData = listOfData[i].split(',')  # each string within each entry will be split into a list containing that data
        listOfData[i] = newData  # replace the string at index i with the new list (newData)

    return listOfData


# Participants will be randomly allocated to one of the experimental conditions (low or high anchor)
# Each participant's condition will depend on the number of participants who have completed each condition
# Therefore, each condition will have the same number of participants
def deriveAnchorCondition(results):

    participantsLowAnchor = 0  # will count the number of participants completing the low anchor condition
    participantsHighAnchor = 0  # will count the number of participants completing the high anchor condition
    anchorConditionIndex = 4  # the index of the anchor condition in the list containing each participant's data

    # If the first participant runs the experiment and exits immediately, the column headings will be written in the csv file
    # Thus, the length of the csv file will be 1, but no participants have completed the experiment yet
    # Therefore, the first participant will be randomly allocated
    if len(results) == 1: anchorCondition = randint(0, 1)

    else:  # for every participant except the first one

        for participant in results[1:]:  # from index 1 onwards, as index 0 contains the headings
            # If participants completed the experiment, the length of the list containing his/her data
            # will be equal to the length of the list containing the column headings
            # This will not count the condition of participants exiting the experiment before finishing,
            # hence will ensure that each condition has the same number of participants completing it
            if len(participant) == len(results[0]):
                if int(participant[anchorConditionIndex]) == 0: participantsLowAnchor += 1
                else: participantsHighAnchor += 1

        if participantsLowAnchor < participantsHighAnchor: anchorCondition = 0
        elif participantsLowAnchor > participantsHighAnchor: anchorCondition = 1
        else: anchorCondition =  randint(0, 1)

    return anchorCondition
